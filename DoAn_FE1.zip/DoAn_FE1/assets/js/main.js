
jQuery.noConflict();
(function ($) {
    // Your jQuery code here, using the $

    $(document).ready(function () {
        $(".product__list>.owl-carousel").owlCarousel({
            loop: true,
            margin: 0,
            nav: true,
            responsive: {
                0: {
                    items: 1
                },
                740: {
                    items: 1
                },
                1023: {
                    items: 2
                }
            }
        });
        $(".latest>.owl-carousel").owlCarousel({
            loop: true,
            margin: 0,
            nav: true,
            responsive: {
                0: {
                    items: 1
                },
                740: {
                    items: 1
                },
                1023: {
                    items: 4
                }
            }
        });
        $(".reviews>.owl-carousel").owlCarousel({
            loop: true,
            margin: 0,
            nav: true,
            responsive: {
                0: {
                    items: 1
                },
                740: {
                    items: 1
                },
                1023: {
                    items: 1
                }
            }
        });
        $(".post>.owl-carousel").owlCarousel({
            loop: true,
            margin: 0,
            nav: true,
            responsive: {
                0: {
                    items: 1
                },
                740: {
                    items: 1
                },
                1023: {
                    items: 1
                }
            }
        });
        $(".featured-categories>.owl-carousel").owlCarousel({
            loop: true,
            margin: 0,
            nav: true,
            responsive: {
                0: {
                    items: 1
                },
                740: {
                    items: 1
                },
                1023: {
                    items: 4
                }
            }
        });
        $(".archive>.owl-carousel").owlCarousel({
            loop: true,
            margin: 0,
            nav: true,
            responsive: {
                0: {
                    items: 1
                },
                740: {
                    items: 3
                },
                1023: {
                    items: 6
                }
            }
        });
    });

})(jQuery);