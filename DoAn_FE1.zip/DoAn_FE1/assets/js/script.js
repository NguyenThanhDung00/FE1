
const $$ = document.querySelector.bind(document)
const $All = document.querySelectorAll.bind(document)
const navMenu = $$('.nav__profile-menu')
const category = $$('.category')
const btnCloseMenu = $$('.category__close-button')

navMenu.onclick = function(){
    category.classList.remove('hide-on-mobile-tablet')
    category.style.animation = "slideLeft ease 0.3s"
    // console.log(category)
}

btnCloseMenu.onclick = function(){
    category.style.animation = "slideRight ease 0.3s"
    setTimeout(() =>{
        category.classList.add('hide-on-mobile-tablet')
    }, 200)
}
